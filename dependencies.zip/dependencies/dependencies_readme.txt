Open up a command line window and from the unzipped dependencies directory,
run the following instructions.

Install Netty
mvn install:install-file -Dfile=netty-all-4.1.8.Final.jar
-DgroupId=io.netty -DartifactId=netty-all -Dversion=4.1.8.Final -Dpackaging=jar

Install Guava
mvn install:install-file -Dfile=guava-21.0.jar
-DgroupId=com.google.guava -DartifactId=guava -Dversion=21.0 -Dpackaging=jar

Install Slf4j-API
mvn install:install-file -Dfile=slf4j-api-1.7.22.jar
-DgroupId=org.slf4j -DartifactId=slf4j-api -Dversion=1.7.22 -Dpackaging=jar

Install Javassist
mvn install:install-file -Dfile=javassist.jar
-DgroupId=javassist -DartifactId=javassist -Dversion=3.21.0-GA -Dpackaging=jar

Install Reflections
mvn install:install-file -Dfile=reflections-0.9.10.Final.jar
-DgroupId=org.reflections -DartifactId=reflections -Dversion=0.9.10 -Dpackaging=jar


Note other dependencies. These do not need be downloaded explicitly.
* JUnit 4.8.2
* Maven Assembly Plugin 3.0.0